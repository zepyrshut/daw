# Ejercicio 1.1
## Errores observados
- Falta de comillas dobles en atributo importancia, en la línea 5.
- Etiqueta de cierre es un corchete en lugar de corchete angular en la etiqueta <code>&lt;/p&gt;</code> en la línea 6.
- Al ser un texto plano, donde debe mostrarse los corchetes angulares y no forma parte de una etiqueta, debe ser abierta con <code>\&lt;</code>, en la línea 7.
- No tiene cierre, se le ha añadido una barra inclinada al final de la línea 9.