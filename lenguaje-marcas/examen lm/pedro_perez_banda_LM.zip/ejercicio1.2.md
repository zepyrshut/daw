# Ejercicio 1.2
## Errores observados
- En la etiqueta autor, en el atributo le falta la doble comillas, en la línea 5.
- En la misma etiqueta, hay un atributo duplicado, se elimina, en la línea 5.
- Además, no tiene el cierre correcto, es con barra inclinada, en la línea 5.
- No procede el corchete angular, con lo que también es eliminado, en la línea 6.
- Sustituido el corchete por corchete angular para la etiquta de cierre de libro. <code>&lt;/libro]</code> a <code>&lt;/libro&gt;</code>, en la línea 7.
- La etiqueta <code>&lt;libros&gt;</code> empieza con mayúsculas, se ha cambiado a minúsculas, en la línea 8.